import java.text.*;
import java.util.*;
import java.util.concurrent.*;

import nl.cwi.pr.runtime.*;
import nl.cwi.pr.runtime.api.*;

public class Main {

	//
	// MAIN
	//

	public static void main(String[] args) {
		long time = -System.nanoTime();

		OutputPort a = Ports.newOutputPort();
		InputPort b = Ports.newInputPort();
		InputPort c = Ports.newInputPort();

		new Protocol_Regulatorwrr(
			a,
			b,
			c
		);



		long timeToInitialize = time + System.nanoTime();

		/*
		 * Run the application as a benchmark 
		 */

		if (Benchmark.IS_ENABLED) {

			/*
			 * Warm up
			 */

			Benchmark.SEMAPHORE.acquireUninterruptibly(0);
			Benchmark.BARRIER = new CyclicBarrier(0 + 1);
			Benchmark.N_GETS.set(0);
			Benchmark.N_PUTS.set(0);

			try {
				Thread.sleep(Benchmark.WARM_UP_TIME * 1000);
			} catch (InterruptedException e) {
			}


			//Benchmark.SEMAPHORE.acquireUninterruptibly(0);
			try {
				Benchmark.BARRIER.await();
			} catch (InterruptedException | BrokenBarrierException exception) {
				exception.printStackTrace();
				System.exit(0);
			}

			/*
			 * Measure
			 */

			try {
				Thread.sleep(Benchmark.MEASURE_TIME * 1000);
			} catch (InterruptedException e) {
			}


			Benchmark.SEMAPHORE.acquireUninterruptibly(0);
			long nPuts = Benchmark.N_PUTS.get();
			long nGets = Benchmark.N_GETS.get();

			System.out
					.println(new DecimalFormat("0.000")
							.format(timeToInitialize / 1e9)
							+ " "
							+ nPuts
							+ " "
							+ nGets);
		}

		/*
		 * Run the application normally
		 */

		else {
			final Map<String, InputPort> freeInputPorts = new HashMap<>();
			final Map<String, OutputPort> freeOutputPorts = new HashMap<>();
			freeInputPorts.put("b", b);
			freeInputPorts.put("c", c);
			freeOutputPorts.put("a", a);
			Thread windowsThread = new Thread() {
				@Override
				public void run() {
					if (!freeInputPorts.isEmpty() || !freeOutputPorts.isEmpty())
						PortWindows.openThenWait(freeInputPorts, freeOutputPorts);
				}
			};

			windowsThread.start();

			while (true)
				try {
					windowsThread.join();
					break;
				} catch (InterruptedException exception) {
				}
		}

		System.exit(0);
	}
}
