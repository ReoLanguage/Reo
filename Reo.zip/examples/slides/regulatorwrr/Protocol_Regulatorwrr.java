import java.util.*;
import java.util.concurrent.atomic.*;

import nl.cwi.pr.runtime.*;
import nl.cwi.pr.runtime.api.*;

public class Protocol_Regulatorwrr {

	//
	// FIELDS
	//

	/*
	 * Automata
	 */

	final Protocol_Regulatorwrr_Automaton7 automaton7;

	/*
	 * Public ports
	 */

	final PublicPort $a;
	final PublicPort $b;
	final PublicPort $c;

	/*
	 * Variable pool
	 */

	final CspVariablePool variablePool = new CspVariablePool();

	//
	// CONSTRUCTORS
	//

	public Protocol_Regulatorwrr(
		Port $a,
		Port $b,
		Port $c
	) {

		/*
		 * Set public ports
		 */

		this.$a = (PublicPort) $a;
		this.$b = (PublicPort) $b;
		this.$c = (PublicPort) $c;

		/*
		 * Set automata
		 */

		this.automaton7 = new Protocol_Regulatorwrr_Automaton7();

		/*
		 * Initialize
		 */

		initialize();

		/*
		 * Return
		 */

		return;
	}

	//
	// METHODS
	//

	public void initialize() {

		/*
		 * Initialize ports in automaton #7
		 */

		{
			this.$a.handler = new HandlerFor$a(this);
			this.$b.handler = new HandlerFor$b(this);
			this.$c.handler = new HandlerFor$c(this);
		}

		/*
		 * Initialize automata
		 */

		this.automaton7.initialize(this);
	}

	//
	// MAIN
	//

	public static void main(String[] args) {
		OutputPort $a = Ports.newOutputPort();
		InputPort $b = Ports.newInputPort();
		InputPort $c = Ports.newInputPort();

		new Protocol_Regulatorwrr(
			$a,
			$b,
			$c
		);

		Map<String, Port> inputPorts = new HashMap<>();
		inputPorts.put("$a", (Port) $a);

		Map<String, Port> outputPorts = new HashMap<>();
		outputPorts.put("$b", (Port) $b);
		outputPorts.put("$c", (Port) $c);

		new Thread(new Console(inputPorts, outputPorts)).start();
	}
}

class Protocol_Regulatorwrr_Automaton7 extends Automaton {

	//
	// FIELDS
	//

	/*
	 * States
	 */

	final Protocol_Regulatorwrr_Automaton7_State1 state1;

	//
	// CONSTRUCTORS
	//

	public Protocol_Regulatorwrr_Automaton7() {
		super(3);

		/*
		 * Set states
		 */

		this.state1 = new Protocol_Regulatorwrr_Automaton7_State1();

		/*
		 * Return
		 */

		return;
	}

	//
	// METHODS
	//

	public void initialize(Protocol_Regulatorwrr protocol) {

		/*
		 * Initialize states
		 */

		this.state1.initialize(protocol);

		/*
		 * Reach initial state
		 */

		this.state1.reach();

		/*
		 * Return
		 */

		return;
	}
}

class Protocol_Regulatorwrr_Automaton7_State1 extends State {

	//
	// FIELDS
	//

	/*
	 * Successor
	 */

	State successor;

	/*
	 * Public ports
	 */

	PublicPort $a;
	PublicPort $b;
	PublicPort $c;

	/*
	 * Transitions
	 */

	final Protocol_Regulatorwrr_Automaton7_Transition2 transition2;

	/*
	 * Observable transitions per port
	 */

			

	/*
	 * Fairness indices for observable transitions
	 */

			
	//
	// CONSTRUCTORS
	//

	public Protocol_Regulatorwrr_Automaton7_State1() {

		/*
		 * Set transitions
		 */

		this.transition2 = new Protocol_Regulatorwrr_Automaton7_Transition2();

		/*
		 * Set observable transitions per port
		 */

						
		/*
		 * Return
		 */

		return;
	}

	//
	// METHODS
	//

	public void initialize(Protocol_Regulatorwrr protocol) {

		/*
		 * Set successor
		 */

		this.successor = protocol.automaton7.state1;
		/*
		 * Set ports 
		 */

		this.$a = protocol.$a;
		this.$b = protocol.$b;
		this.$c = protocol.$c;

		/*
		 * Initialize transitions
		 */

		this.transition2.initialize(protocol);

		/*
		 * Return
		 */

		return;
	}

	@Override
	public void reach() {

		/*
		 * Unblock public ports
		 */

		$a.semaphore.release();
		$b.semaphore.release();
		$c.semaphore.release();

		/*
		 * Return
		 */

		return;
	}

	@Override
	public void reachSuccessor() {
		successor.reach();
	}
}

class Protocol_Regulatorwrr_Automaton7_Transition2 extends Transition {

	//
	// FIELDS
	//

	/*
	 * Context
	 */

	Context context;

	/*
	 * Public ports
	 */

	PublicPort $a;
	PublicPort $b;
	PublicPort $c;

	/*
	 * Data constraint
	 */

	DataConstraint dataConstraint;

	/*
	 * Target
	 */

	Protocol_Regulatorwrr_Automaton7_State1 target;

	//
	// METHODS - PUBLIC
	//

	@Override
	public boolean fire() {

		/*
		 * Check synchronization/data constraint
		 */

		boolean canFire = checkSynchronizationSet() && checkDataConstraint();

		/*
		 * Finalize transition
		 */

		if (canFire) {

			/*
			 * Update context
			 */

			context.remove(0, 0b00000000000000000000000000000111);

			/*
			 * Unblock ports
			 */

			$a.status = IO.COMPLETED;
			$a.semaphore.release();
			$b.status = IO.COMPLETED;
			$b.semaphore.release();
			$c.status = IO.COMPLETED;
			$c.semaphore.release();

			/*
			 * Update current state
			 */

			target.reach();
		}

		/*
		 * Return
		 */

		return canFire;
	}

	public void initialize(Protocol_Regulatorwrr protocol) {

		/*
		 * Set context
		 */

		this.context = protocol.automaton7.context;

		/*
		 * Set ports 
		 */

		this.$a = protocol.$a;
		this.$b = protocol.$b;
		this.$c = protocol.$c;

		/*
		 * Set data constraint and target
		 */

		this.dataConstraint = new DataConstraint(protocol);

		/*
		 * Set target
		 */

		this.target = protocol.automaton7.state1;

		/*
		 * Return
		 */

		 return;
	}

	//
	// METHODS - PROTECTED
	//

	@Override
	protected boolean checkDataConstraint() {
		return dataConstraint.solve();
	}

	protected boolean checkSynchronizationSet() {
		return true
			&& context.contains(0, 0b00000000000000000000000000000111)
;
	}

	//
	// CLASSES
	//

	class DataConstraint {

		//
		// FIELDS
		//

		/*
		 * Public port variables
		 */

		final private CspPortVariable $a;
		final private CspPortVariable $b;
		final private CspPortVariable $c;

		//
		// CONSTRUCTORS
		//

		public DataConstraint(Protocol_Regulatorwrr protocol) {

			/*
			 * Set variables
			 */

			this.$a = protocol.variablePool.newOrGetPortVariable(protocol.$a);
			this.$b = protocol.variablePool.newOrGetPortVariable(protocol.$b);
			this.$c = protocol.variablePool.newOrGetPortVariable(protocol.$c);

			/*
			 * Return
			 */

			return;
		}

		public boolean solve() {
			$a.importValue();
			$b.setValue($a.getValue());
			$c.setValue($a.getValue());
			$b.exportValue();
			$c.exportValue();
			return true;
		}
	}
}

class HandlerFor$a extends Handler {

	//
	// FIELDS
	//

	/*
	 * Context and port
	 */

	final Context context;
	final PublicPort $a;

	/*
	 * States
	 */

	final Protocol_Regulatorwrr_Automaton7_State1 state1;

	//
	// CONSTRUCTORS
	//

	public HandlerFor$a(Protocol_Regulatorwrr protocol) {
		super(protocol.automaton7.semaphore);

		/*
		 * Set context and port
		 */

		this.context = protocol.automaton7.context;
		this.$a = protocol.$a;

		/*
		 * Set states
		 */

		this.state1 = protocol.automaton7.state1;

		/*
		 * Return
		 */

		return;
	}

	//
	// METHODS
	//

	@Override
	public boolean call() {
		if ($a.status == IO.COMPLETED)
			return true;

		if (fireTransitionFromState1())
			return true;

		$a.semaphore.drainPermits();
		return false;
	}

	@Override
	public boolean cancel() {
		context.remove(0, 0b00000000000000000000000000000001);
		IO status = $a.status;
		$a.status = null;
		return status == IO.COMPLETED;
	}

	@Override
	public void flag() {
		context.add(0, 0b00000000000000000000000000000001);
	}




	private boolean fireTransitionFromState1() {
		return state1.transition2.fire();
	}
}

class HandlerFor$b extends Handler {

	//
	// FIELDS
	//

	/*
	 * Context and port
	 */

	final Context context;
	final PublicPort $b;

	/*
	 * States
	 */

	final Protocol_Regulatorwrr_Automaton7_State1 state1;

	//
	// CONSTRUCTORS
	//

	public HandlerFor$b(Protocol_Regulatorwrr protocol) {
		super(protocol.automaton7.semaphore);

		/*
		 * Set context and port
		 */

		this.context = protocol.automaton7.context;
		this.$b = protocol.$b;

		/*
		 * Set states
		 */

		this.state1 = protocol.automaton7.state1;

		/*
		 * Return
		 */

		return;
	}

	//
	// METHODS
	//

	@Override
	public boolean call() {
		if ($b.status == IO.COMPLETED)
			return true;

		if (fireTransitionFromState1())
			return true;

		$b.semaphore.drainPermits();
		return false;
	}

	@Override
	public boolean cancel() {
		context.remove(0, 0b00000000000000000000000000000010);
		IO status = $b.status;
		$b.status = null;
		return status == IO.COMPLETED;
	}

	@Override
	public void flag() {
		context.add(0, 0b00000000000000000000000000000010);
	}




	private boolean fireTransitionFromState1() {
		return state1.transition2.fire();
	}
}

class HandlerFor$c extends Handler {

	//
	// FIELDS
	//

	/*
	 * Context and port
	 */

	final Context context;
	final PublicPort $c;

	/*
	 * States
	 */

	final Protocol_Regulatorwrr_Automaton7_State1 state1;

	//
	// CONSTRUCTORS
	//

	public HandlerFor$c(Protocol_Regulatorwrr protocol) {
		super(protocol.automaton7.semaphore);

		/*
		 * Set context and port
		 */

		this.context = protocol.automaton7.context;
		this.$c = protocol.$c;

		/*
		 * Set states
		 */

		this.state1 = protocol.automaton7.state1;

		/*
		 * Return
		 */

		return;
	}

	//
	// METHODS
	//

	@Override
	public boolean call() {
		if ($c.status == IO.COMPLETED)
			return true;

		if (fireTransitionFromState1())
			return true;

		$c.semaphore.drainPermits();
		return false;
	}

	@Override
	public boolean cancel() {
		context.remove(0, 0b00000000000000000000000000000100);
		IO status = $c.status;
		$c.status = null;
		return status == IO.COMPLETED;
	}

	@Override
	public void flag() {
		context.add(0, 0b00000000000000000000000000000100);
	}




	private boolean fireTransitionFromState1() {
		return state1.transition2.fire();
	}
}
