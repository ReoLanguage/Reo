import nl.cwi.pr.runtime.api.InputPort;
import nl.cwi.pr.runtime.api.OutputPort;
import nl.cwi.reo.runtime.java.Input;
import nl.cwi.reo.runtime.java.Output;

public class Workers {

	// Lykos

	public static void producer1(OutputPort a) {
		for (int i = 0; i < 2; i++)
			a.putUninterruptibly("hello" + i);
	}

	public static void consumer1(InputPort b) {
		for (int i = 0; i < 20; i++)
			System.out.println(b.getUninterruptibly());
	}
	
	// Ours

	public static void producer2(Output<String> a) {
		for (int i = 0; i < 2; i++)
			a.put("hello" + i);
	}
	
	public static void consumer2(Input<String> a) {
		for (int i = 0; i < 20; i++)
			System.out.println(a.get());
	}
}
