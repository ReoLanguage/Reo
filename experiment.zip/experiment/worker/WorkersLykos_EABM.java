import java.io.IOException;
import java.io.PrintWriter;

import nl.cwi.pr.runtime.api.InputPort;
import nl.cwi.pr.runtime.api.OutputPort;

public class WorkersLykos {
	
	static int N=1000*100;
	static int k=4;

	public static void producer(OutputPort port) {
		Long t1 = System.nanoTime();
		while((System.nanoTime()-t1)/1000000000 < 20){
			port.putUninterruptibly("d");
		}

		while(true)
			port.putUninterruptibly("d");
	}

	public static void consumer(InputPort port) {
                Long t1 = System.nanoTime();
                while((System.nanoTime()-t1)/1000000000 < 20){
			port.getUninterruptibly();
                }

                Long t2 = System.nanoTime();
                for (int i = 0; i < k*N; i++){
			port.getUninterruptibly();
                }
                Long t3 = System.nanoTime();
                Long t = (t3-t2)/(100) ;
                try{
                        PrintWriter writer = new PrintWriter(
							"result_execution.txt"
						, "UTF-8");
                        writer.println("time for N put and k*N get :"+t);
                        writer.close();
                } catch (IOException e) { // do something  
                }
                System.out.println(" done ");
                System.exit(0);

	}
}

