#!/bin/bash

# $1 is the max value of k for experiment; $2 is the iteration value.


#seq
  sh compile.sh 150 10 earlyAsyncReplicator
  sh javaCompile.sh 150 10 earlyAsyncReplicator Workers_EAR.java exec_$1
  sh compileToLykosPT.sh 150 10 earlyAsyncReplicator
  sh javaCompileLykos.sh 150 10 earlyAsyncReplicator WorkersLykos_EAR.java exec_lykos_$1
