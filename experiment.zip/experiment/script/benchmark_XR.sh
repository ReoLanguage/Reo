#!/bin/bash

# $1 is the max value of k for experiment; $2 is the iteration value.


#seq
  sh compile.sh 400 10 xrouter
  sh javaCompile.sh 400 10 xrouter Workers_XR.java exec_$1
  sh compileToLykosPT.sh 10 2 xrouter
  sh javaCompileLykos.sh 10 2 xrouter WorkersLykos_XR.java exec_lykos_$1
