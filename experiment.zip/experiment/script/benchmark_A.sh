#!/bin/bash

# $1 is the max value of k for experiment; $2 is the iteration value.


#seq
  sh compile.sh 1000 50 alternator 
  sh javaCompile.sh 400 50 alternator Workers1.java exec_$3.txt
