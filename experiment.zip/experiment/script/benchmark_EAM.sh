#!/bin/bash

# $1 is the max value of k for experiment; $2 is the iteration value.


#seq
  sh compile.sh 10 1 earlyAsyncMerger
  sh javaCompile.sh 10 1 earlyAsyncMerger Workers_EAM.java exec_$1
  sh compile.sh 100 5 earlyAsyncMerger
  sh javaCompile.sh 100 5 earlyAsyncMerger Workers_EAM.java exec_$1
  sh compileToLykosPT.sh 10 1 earlyAsyncMerger
  sh javaCompileLykos.sh 10 1 earlyAsyncMerger Workers_EAM.java exec_$1
  sh compileToLykosPT.sh 100 5 earlyAsyncMerger
  sh javaCompileLykos.sh 100 5 earlyAsyncMerger WorkersLykos_EAM.java exec_lykos_$1
