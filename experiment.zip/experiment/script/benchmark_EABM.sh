#!/bin/bash

# $1 is the max value of k for experiment; $2 is the iteration value.


#seq
  sh compile.sh 300 10 earlyAsyncBarrierMerger
  sh javaCompile.sh 300 10 earlyAsyncBarrierMerger Workers_EABM.java exec_$1
  sh compileToLykosPT.sh 300 10 earlyAsyncBarrierMerger
  sh javaCompileLykos.sh 300 10 earlyAsyncBarrierMerger WorkersLykos_EABM.java exec_lykos_$1
