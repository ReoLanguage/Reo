#!/bin/sh

gnuplot -p -e "file1='../new/earlyAsyncMerger/comp.txt'; file2='../new/earlyAsyncMerger/comp_lykos.txt'; title='../new/earlyAsyncMerger/comp.eps'" eam_comp.gnuplot
gnuplot -p -e "file1='../new/earlyAsyncMerger/exec.txt'; file2='../new/earlyAsyncMerger/exec_lykos.txt'; title='../new/earlyAsyncMerger/exec.eps'" smooth_eam.gnuplot

gnuplot -p -e "file1='../new/earlyAsyncBarrierMerger/comp.txt'; file2='../new/earlyAsyncBarrierMerger/comp_lykos.txt'; title='../new/earlyAsyncBarrierMerger/comp.eps'" eabm_comp.gnuplot
gnuplot -p -e "file1='../new/earlyAsyncBarrierMerger/exec.txt'; file2='../new/earlyAsyncBarrierMerger/exec_lykos.txt'; title='../new/earlyAsyncBarrierMerger/exec.eps'" eabm_exec.gnuplot

gnuplot -p -e "file1='../new/xrouter/comp.txt'; file2='../new/xrouter/comp_lykos.txt'; title='../new/xrouter/comp.eps'" comp.gnuplot
gnuplot -p -e "file1='../new/xrouter/exec.txt'; file2='../new/xrouter/exec_lykos.txt'; title='../new/xrouter/exec.eps'" smooth.gnuplot

gnuplot -p -e "file1='../new/alternator/comp.txt'; file2='../new/alternator/comp_lykos.txt'; title='../new/alternator/comp.eps'" alt_comp.gnuplot
gnuplot -p -e "file1='../new/alternator/exec.txt'; file2='../new/alternator/exec_lykos.txt'; title='../new/alternator/exec.eps'" alt_exec.gnuplot

gnuplot -p -e "file1='../new/earlyAsyncReplicator/comp.txt'; file2='../new/earlyAsyncReplicator/comp_lykos.txt'; title='../new/earlyAsyncReplicator/comp.eps'" ear_comp.gnuplot
gnuplot -p -e "file1='../new/earlyAsyncReplicator/exec.txt'; file2='../new/earlyAsyncReplicator/exec_lykos.txt'; title='../new/earlyAsyncReplicator/exec.eps'" ear_exec.gnuplot

epstopdf ../new/alternator/comp.eps
epstopdf ../new/alternator/exec.eps
epstopdf ../new/earlyAsyncBarrierMerger/comp.eps
epstopdf ../new/earlyAsyncBarrierMerger/exec.eps
epstopdf ../new/earlyAsyncMerger/comp.eps
epstopdf ../new/earlyAsyncMerger/exec.eps
epstopdf ../new/xrouter/exec.eps
epstopdf ../new/xrouter/comp.eps
epstopdf ../new/earlyAsyncReplicator/exec.eps
epstopdf ../new/earlyAsyncReplicator/comp.eps
